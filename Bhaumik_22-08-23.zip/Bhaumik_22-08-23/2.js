let friends = [
    {
        name: "Anna",
        books: ['bible', "Harry Potter"],
        age: 21
    },
    {
        name: "Bob",
        books: ['war', "romeo"],
        age: 21
    },
    {
        name: "Anna",
        books: ['the lord', "shining"],
        age: 21
    },
]
function returnBooks(arr) {
    let a = arr.map((ele) => {
        return ele.books
    });
    return a.flat();
}
console.log(returnBooks(friends));